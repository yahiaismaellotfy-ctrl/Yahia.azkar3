import React, { useState } from 'react';
import { Crown, Heart, Megaphone, MessageCircle, Sparkles } from 'lucide-react';

export const WHATSAPP_CHANNEL_URL = 'https://whatsapp.com/channel/0029VbBHjuc35fLzD0p4Fu0u';
export const APP_COVER_IMAGE = '/assets/aistudio/file_000000005e0482469815059f1f5a3acd_69bd9b10.png';
export const DEVELOPER_AVATAR_IMAGE = '/assets/aistudio/YAHIA_DISTROVA_2MB_9b532cd6.jpg';

export const AppFooter: React.FC = () => {
  const [imgError, setImgError] = useState(false);

  return (
    <footer className="relative mt-8 overflow-hidden rounded-[28px] border-2 border-amber-400/55 bg-gradient-to-b from-[#170938] via-[#1b0b47] to-[#0c0726] p-5 sm:p-6 shadow-[0_18px_50px_rgba(12,4,36,0.85)]">
      {/* Ambient Royal Purple & Golden Light Glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-20 left-1/2 h-44 w-72 -translate-x-1/2 rounded-full bg-violet-500/25 blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-16 right-1/4 h-36 w-56 rounded-full bg-amber-400/15 blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-[2px] bg-gradient-to-l from-transparent via-amber-300 to-transparent"
      />

      <div className="relative flex flex-col items-center text-center gap-5">
        {/* Top Golden-Rimmed Crown Pill */}
        <div className="inline-flex items-center gap-2 rounded-full border border-amber-300/65 bg-gradient-to-l from-[#2b1066]/90 via-[#1d0b49]/95 to-[#2b1066]/90 px-5 py-1.5 shadow-[0_0_24px_rgba(251,191,36,0.22)]">
          <Crown className="h-4 w-4 text-amber-300 shrink-0" />
          <span className="text-xs sm:text-sm font-extrabold text-amber-200 tracking-wide">
            القناة الرسمية على واتساب
          </span>
        </div>

        {/* Upper Showcase Row: Promo Text + Developer Avatar */}
        <div className="flex w-full flex-col-reverse sm:flex-row items-center justify-between gap-4 rounded-2xl border border-violet-300/20 bg-white/[0.04] p-4 backdrop-blur-sm">
          <div className="flex-1 text-center sm:text-right min-w-0">
            <p className="inline-flex items-center justify-center sm:justify-start gap-2 text-sm sm:text-base font-extrabold text-white leading-relaxed">
              <Megaphone className="h-5 w-5 text-amber-300 shrink-0" />
              <span>تابع قناتنا الرسمية الآن</span>
            </p>
            <p className="mt-1 text-xs sm:text-sm font-semibold leading-relaxed text-amber-100/90">
              للحصول على آخر التحديثات، والمميزات الجديدة، والتنبيهات المستمرة !
            </p>
          </div>

          <div className="relative shrink-0">
            <div
              aria-hidden="true"
              className="absolute -inset-1.5 rounded-2xl bg-gradient-to-br from-amber-300/65 via-violet-500/55 to-amber-400/65 blur-sm"
            />
            {!imgError ? (
              <img
                src={DEVELOPER_AVATAR_IMAGE}
                alt="شعار المطور YAHIA DISTROVA"
                referrerPolicy="no-referrer"
                onError={() => setImgError(true)}
                className="relative h-24 w-24 sm:h-28 sm:w-28 rounded-2xl border-2 border-amber-300/80 object-cover shadow-2xl"
              />
            ) : (
              <div className="relative flex h-24 w-24 sm:h-28 sm:w-28 items-center justify-center rounded-2xl border-2 border-amber-300/80 bg-gradient-to-br from-violet-700 to-blue-800 text-amber-200">
                <Heart className="h-9 w-9" />
              </div>
            )}
          </div>
        </div>

        {/* Ornate Royal Credit Banner */}
        <div className="w-full rounded-2xl border border-amber-300/45 bg-gradient-to-l from-[#240d54]/90 via-[#31136e]/90 to-[#240d54]/90 px-4 py-3 shadow-[0_0_24px_rgba(139,92,246,0.28)]">
          <p className="text-xs sm:text-sm font-bold text-slate-100">
            تم تصميم وتطوير بوصطت المطور
          </p>
          <p className="mt-1 text-sm sm:text-base font-extrabold tracking-wider text-amber-300">
            𝐘𝐀𝐇𝐈𝐀 𝐃𝐈𝐒𝐓𝐑𝐎𝐕𝐀 | 𓏺ᴠͥɪͣᴘͫ𓏺
          </p>
        </div>

        {/* Prominent New Developer Title Spotlight */}
        <div className="w-full space-y-1.5">
          <div className="flex items-center justify-center gap-3">
            <span className="h-[1px] flex-1 max-w-[90px] bg-gradient-to-l from-amber-300/80 to-transparent" />
            <p className="text-xs sm:text-sm font-extrabold text-amber-200 flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-amber-300 shrink-0" />
              <span>الـمـطـوࢪ الـجـديـد 𝐘𝐀𝐇𝐈𝐀</span>
              <Sparkles className="h-3.5 w-3.5 text-amber-300 shrink-0" />
            </p>
            <span className="h-[1px] flex-1 max-w-[90px] bg-gradient-to-r from-amber-300/80 to-transparent" />
          </div>

          <div className="flex items-center justify-center gap-2">
            <span aria-hidden="true" className="text-amber-300/80 text-lg sm:text-xl select-none">
              ✦
            </span>
            <h3 className="bg-gradient-to-b from-amber-100 via-amber-300 to-amber-500 bg-clip-text text-3xl sm:text-4xl font-black tracking-[0.2em] text-transparent drop-shadow-[0_2px_12px_rgba(251,191,36,0.38)]">
              𝐘𝐀𝐇𝐈𝐀
            </h3>
            <span aria-hidden="true" className="text-amber-300/80 text-lg sm:text-xl select-none">
              ✦
            </span>
          </div>
        </div>

        {/* Glowing Emerald WhatsApp Channel CTA Button */}
        <a
          href={WHATSAPP_CHANNEL_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-glow group flex w-full items-center justify-center gap-3 rounded-full border-2 border-amber-300/75 bg-gradient-to-l from-emerald-600 via-green-600 to-teal-600 px-5 py-3.5 text-white shadow-[0_0_28px_rgba(16,185,129,0.45)] transition-transform active:scale-[0.98]"
        >
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-emerald-600 shadow-md ring-2 ring-amber-200/70">
            <MessageCircle className="h-5 w-5 fill-emerald-600 text-white" />
          </span>
          <span className="text-sm sm:text-base font-extrabold text-amber-100 leading-snug">
            مـتـابـعـه هـنـا يـاقـلـب اخـوكـ/ـى♥✨🐉
          </span>
        </a>
      </div>
    </footer>
  );
};
