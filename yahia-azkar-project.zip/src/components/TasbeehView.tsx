import React, { useMemo, useState } from 'react';
import {
  Award,
  CheckCircle2,
  Edit3,
  Layers,
  Plus,
  RotateCcw,
  Sparkles,
  Trash2,
  Undo2,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { DHIKR_PRESETS } from '../data/azkarData';
import { playGoalChime, triggerHaptic } from '../utils/reminderAudio';
import type {
  AppSettings,
  CustomTasbeehCounter,
  TasbeehState,
} from '../utils/storage';

interface TasbeehViewProps {
  tasbeeh: TasbeehState;
  settings: AppSettings;
  onUpdateTasbeeh: (next: TasbeehState) => void;
}

const GOAL_PRESETS = [33, 100, 300, 1000];

export const TasbeehView: React.FC<TasbeehViewProps> = ({
  tasbeeh,
  settings,
  onUpdateTasbeeh,
}) => {
  const [showGoalCelebration, setShowGoalCelebration] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [customGoalInput, setCustomGoalInput] = useState('');
  const [tapPulse, setTapPulse] = useState(false);

  // Add / Edit custom counter modal state
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingCounterId, setEditingCounterId] = useState<string | null>(null);
  const [formName, setFormName] = useState('');
  const [formDhikr, setFormDhikr] = useState('');
  const [formGoal, setFormGoal] = useState('100');
  const [formError, setFormError] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const activeCounter = useMemo(
    () =>
      tasbeeh.counters.find((c) => c.id === tasbeeh.activeCounterId) ||
      tasbeeh.counters[0],
    [tasbeeh.counters, tasbeeh.activeCounterId]
  );

  const progress = Math.min(
    1,
    activeCounter.currentCount / Math.max(1, activeCounter.dailyGoal)
  );
  const radius = 108;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - progress);

  const commitCounterUpdate = (
    updatedCounter: CustomTasbeehCounter,
    nextCountersList?: CustomTasbeehCounter[],
    lifetimeDelta = 0
  ) => {
    const counters = (nextCountersList || tasbeeh.counters).map((c) =>
      c.id === updatedCounter.id ? updatedCounter : c
    );
    onUpdateTasbeeh({
      ...tasbeeh,
      activeCounterId: updatedCounter.id,
      counters,
      currentCount: updatedCounter.currentCount,
      dailyGoal: updatedCounter.dailyGoal,
      selectedDhikr: updatedCounter.dhikrText,
      completedRounds: updatedCounter.completedRounds,
      totalLifetimeCount: Math.max(0, tasbeeh.totalLifetimeCount + lifetimeDelta),
      lastUpdatedDate: new Date().toISOString().slice(0, 10),
    });
  };

  const handleSelectCounter = (counter: CustomTasbeehCounter) => {
    setConfirmReset(false);
    setConfirmDeleteId(null);
    onUpdateTasbeeh({
      ...tasbeeh,
      activeCounterId: counter.id,
      currentCount: counter.currentCount,
      dailyGoal: counter.dailyGoal,
      selectedDhikr: counter.dhikrText,
      completedRounds: counter.completedRounds,
    });
  };

  const handleTap = () => {
    const nextCount = activeCounter.currentCount + 1;
    const hitGoal = nextCount === activeCounter.dailyGoal;

    if (settings.tapVibration) {
      triggerHaptic(hitGoal && settings.goalVibration ? [40, 60, 80] : 22);
    }

    if (hitGoal) {
      playGoalChime();
      setShowGoalCelebration(true);
    }

    setTapPulse(true);
    setTimeout(() => setTapPulse(false), 160);

    commitCounterUpdate(
      {
        ...activeCounter,
        currentCount: nextCount,
        totalCount: activeCounter.totalCount + 1,
        completedRounds: hitGoal
          ? activeCounter.completedRounds + 1
          : activeCounter.completedRounds,
      },
      undefined,
      1
    );
  };

  const handleUndo = () => {
    if (activeCounter.currentCount <= 0) return;
    if (settings.tapVibration) {
      triggerHaptic(15);
    }
    commitCounterUpdate(
      {
        ...activeCounter,
        currentCount: Math.max(0, activeCounter.currentCount - 1),
        totalCount: Math.max(0, activeCounter.totalCount - 1),
      },
      undefined,
      -1
    );
  };

  const handleReset = () => {
    if (!confirmReset) {
      setConfirmReset(true);
      setTimeout(() => setConfirmReset(false), 3500);
      return;
    }
    setConfirmReset(false);
    commitCounterUpdate({
      ...activeCounter,
      currentCount: 0,
    });
  };

  const handleSelectDhikr = (text: string) => {
    commitCounterUpdate({
      ...activeCounter,
      dhikrText: text,
    });
  };

  const handleSetGoal = (goal: number) => {
    if (!Number.isFinite(goal) || goal < 1) return;
    commitCounterUpdate({
      ...activeCounter,
      dailyGoal: Math.min(100000, Math.round(goal)),
    });
  };

  const openCreateModal = () => {
    setEditingCounterId(null);
    setFormName('');
    setFormDhikr('');
    setFormGoal('100');
    setFormError(null);
    setEditorOpen(true);
  };

  const openEditModal = (counter: CustomTasbeehCounter, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingCounterId(counter.id);
    setFormName(counter.name);
    setFormDhikr(counter.dhikrText);
    setFormGoal(String(counter.dailyGoal));
    setFormError(null);
    setEditorOpen(true);
  };

  const handleSaveCounterForm = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = formName.trim();
    const cleanDhikr = formDhikr.trim() || cleanName;
    const parsedGoal = Math.max(1, Math.min(100000, Math.round(Number(formGoal) || 100)));

    if (!cleanName) {
      setFormError('من فضلك أدخل اسم العداد (مثل: عداد الصلوات على النبي)');
      return;
    }

    if (editingCounterId) {
      const target = tasbeeh.counters.find((c) => c.id === editingCounterId);
      if (!target) return;
      const updated: CustomTasbeehCounter = {
        ...target,
        name: cleanName,
        dhikrText: cleanDhikr,
        dailyGoal: parsedGoal,
      };
      const updatedList = tasbeeh.counters.map((c) =>
        c.id === editingCounterId ? updated : c
      );
      if (tasbeeh.activeCounterId === editingCounterId) {
        commitCounterUpdate(updated, updatedList);
      } else {
        onUpdateTasbeeh({ ...tasbeeh, counters: updatedList });
      }
    } else {
      const newCounter: CustomTasbeehCounter = {
        id: `counter-${Date.now()}`,
        name: cleanName,
        dhikrText: cleanDhikr,
        currentCount: 0,
        dailyGoal: parsedGoal,
        totalCount: 0,
        completedRounds: 0,
        createdAt: Date.now(),
      };
      const updatedList = [...tasbeeh.counters, newCounter];
      commitCounterUpdate(newCounter, updatedList);
    }

    setEditorOpen(false);
  };

  const handleDeleteCounter = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tasbeeh.counters.length <= 1) return;

    if (confirmDeleteId !== id) {
      setConfirmDeleteId(id);
      setTimeout(() => setConfirmDeleteId(null), 3500);
      return;
    }

    setConfirmDeleteId(null);
    const remaining = tasbeeh.counters.filter((c) => c.id !== id);
    const nextActive =
      id === tasbeeh.activeCounterId ? remaining[0] : activeCounter;

    onUpdateTasbeeh({
      ...tasbeeh,
      counters: remaining,
      activeCounterId: nextActive.id,
      currentCount: nextActive.currentCount,
      dailyGoal: nextActive.dailyGoal,
      selectedDhikr: nextActive.dhikrText,
      completedRounds: nextActive.completedRounds,
    });
  };

  const activePreset = DHIKR_PRESETS.find((p) => p.text === activeCounter.dhikrText);

  return (
    <div className="w-full min-w-0 max-w-full overflow-x-clip space-y-6">
      {/* Custom Multi-Counters Switcher Bar */}
      <section className="min-w-0 rounded-3xl border border-violet-300/20 bg-[#150f44]/85 p-4 sm:p-5 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Layers className="h-5 w-5 text-amber-300 shrink-0" />
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-white">
                عدادات التسبيح المخصصة
              </h2>
              <p className="text-xs text-slate-300">
                اختر عداداً أو أضف تسبيحاً جديداً ليتم حفظ كل عداد بشكل مستقل
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={openCreateModal}
            className="btn-glow min-h-[44px] flex items-center gap-2 rounded-2xl bg-gradient-to-l from-violet-600 to-blue-600 px-4 py-2 text-xs sm:text-sm font-bold text-white shadow-lg whitespace-nowrap shrink-0"
          >
            <Plus className="h-4 w-4 shrink-0" />
            <span>إضافة عداد جديد</span>
          </button>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {tasbeeh.counters.map((counter) => {
            const isActive = counter.id === activeCounter.id;
            const pct = Math.min(
              100,
              Math.round((counter.currentCount / Math.max(1, counter.dailyGoal)) * 100)
            );
            const isConfirmingDelete = confirmDeleteId === counter.id;

            return (
              <div
                key={counter.id}
                role="button"
                tabIndex={0}
                onClick={() => handleSelectCounter(counter)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    handleSelectCounter(counter);
                  }
                }}
                className={`btn-glow cursor-pointer rounded-2xl border p-3.5 text-right transition-colors ${
                  isActive
                    ? 'border-amber-300/70 bg-gradient-to-l from-violet-600/45 to-blue-700/45 shadow-lg shadow-violet-950/40'
                    : 'border-white/10 bg-white/5 hover:bg-white/10'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <h3 className="text-sm font-extrabold text-white truncate">
                      {counter.name}
                    </h3>
                    <p className="mt-0.5 text-xs text-slate-300 line-clamp-1">
                      {counter.dhikrText}
                    </p>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => openEditModal(counter, e)}
                      aria-label={`تعديل ${counter.name}`}
                      className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 text-slate-200 hover:bg-white/20"
                    >
                      <Edit3 className="h-3.5 w-3.5" />
                    </button>
                    {tasbeeh.counters.length > 1 && (
                      <button
                        type="button"
                        onClick={(e) => handleDeleteCounter(counter.id, e)}
                        aria-label={`حذف ${counter.name}`}
                        className={`flex h-8 min-w-[32px] items-center justify-center rounded-lg px-1.5 text-[11px] font-bold transition-colors ${
                          isConfirmingDelete
                            ? 'bg-rose-600 text-white'
                            : 'bg-white/10 text-rose-300 hover:bg-rose-600/30'
                        }`}
                      >
                        {isConfirmingDelete ? 'تأكيد' : <Trash2 className="h-3.5 w-3.5" />}
                      </button>
                    )}
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between text-xs">
                  <span className="font-mono-num font-bold text-amber-300">
                    {counter.currentCount} / {counter.dailyGoal}
                  </span>
                  <span className="text-slate-300">
                    الإجمالي: <span className="font-mono-num font-semibold text-white">{counter.totalCount}</span>
                  </span>
                </div>

                <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-black/30">
                  <div
                    className="h-full rounded-full bg-gradient-to-l from-amber-400 via-violet-400 to-blue-400 transition-all duration-300"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Main Counter & Presets Grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 items-start">
        {/* Interactive Circular Counter */}
        <section className="min-w-0 lg:col-span-7 rounded-3xl border border-violet-300/20 bg-gradient-to-br from-[#190f49]/85 via-[#17124d]/85 to-[#0c1d52]/90 p-5 sm:p-8 shadow-2xl flex flex-col items-center text-center">
          <p className="text-xs font-semibold text-amber-300">{activeCounter.name}</p>
          <h2 className="mt-2 max-w-full break-words font-quran text-2xl sm:text-3xl font-bold leading-relaxed text-white [text-wrap:balance]">
            {activeCounter.dhikrText}
          </h2>
          {activePreset && (
            <p className="mt-1.5 text-xs text-slate-300">{activePreset.reward}</p>
          )}

          {/* Circular Progress Button */}
          <div className="relative my-6 flex max-w-full items-center justify-center">
            <svg className="h-60 w-60 sm:h-64 sm:w-64 max-w-full -rotate-90 transform" viewBox="0 0 240 240">
              <circle
                cx="120"
                cy="120"
                r={radius}
                stroke="rgba(255,255,255,0.1)"
                strokeWidth="12"
                fill="none"
              />
              <circle
                cx="120"
                cy="120"
                r={radius}
                stroke="url(#tasbeehGradient)"
                strokeWidth="12"
                strokeLinecap="round"
                fill="none"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className="transition-all duration-300"
              />
              <defs>
                <linearGradient id="tasbeehGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#c084fc" />
                  <stop offset="50%" stopColor="#60a5fa" />
                  <stop offset="100%" stopColor="#fbbf24" />
                </linearGradient>
              </defs>
            </svg>

            <button
              type="button"
              onClick={handleTap}
              aria-label={`اضغط للتسبيح في ${activeCounter.name}`}
              className={`btn-glow absolute flex h-44 w-44 sm:h-48 sm:w-48 flex-col items-center justify-center rounded-full border border-violet-300/35 bg-gradient-to-br from-violet-600/80 via-indigo-700/85 to-blue-700/85 shadow-2xl shadow-violet-950/70 select-none transition-transform duration-150 ${
                tapPulse ? 'scale-95 ring-4 ring-amber-300/60' : 'scale-100'
              }`}
            >
              <span className="font-mono-num text-5xl sm:text-6xl font-extrabold text-white">
                {activeCounter.currentCount}
              </span>
              <span className="mt-1.5 text-xs font-semibold text-violet-100">
                الهدف: <span className="font-mono-num">{activeCounter.dailyGoal}</span>
              </span>
              <span className="mt-2 text-[11px] font-bold text-amber-200">اضغط للتسبيح</span>
            </button>
          </div>

          {/* Undo & Reset Action Bar */}
          <div className="flex flex-wrap items-center justify-center gap-3 w-full">
            <button
              type="button"
              onClick={handleUndo}
              disabled={activeCounter.currentCount <= 0}
              className="btn-glow min-h-[46px] flex items-center gap-2 rounded-2xl border border-violet-300/25 bg-white/10 px-5 py-2.5 text-sm font-bold text-white hover:bg-white/15 disabled:opacity-40"
            >
              <Undo2 className="h-4 w-4 text-amber-300 shrink-0" />
              <span>تراجع (-١)</span>
            </button>

            <button
              type="button"
              onClick={handleReset}
              className={`btn-glow min-h-[46px] flex items-center gap-2 rounded-2xl border px-5 py-2.5 text-sm font-bold ${
                confirmReset
                  ? 'border-rose-400 bg-rose-600/80 text-white'
                  : 'border-white/15 bg-white/5 text-slate-200 hover:bg-white/10'
              }`}
            >
              <RotateCcw className="h-4 w-4 shrink-0" />
              <span>{confirmReset ? 'اضغط للتأكيد' : 'تصفير هذا العداد'}</span>
            </button>
          </div>

          {/* Stats Footer */}
          <div className="mt-6 grid w-full grid-cols-3 gap-3 border-t border-white/10 pt-4 text-center">
            <div>
              <p className="text-xs text-slate-300">النسبة</p>
              <p className="mt-0.5 font-mono-num text-lg font-bold text-amber-300">
                {Math.round(progress * 100)}%
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-300">إجمالي هذا العداد</p>
              <p className="mt-0.5 font-mono-num text-lg font-bold text-violet-200">
                {activeCounter.totalCount}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-300">المجموع الكلي</p>
              <p className="mt-0.5 font-mono-num text-lg font-bold text-blue-200">
                {tasbeeh.totalLifetimeCount}
              </p>
            </div>
          </div>
        </section>

        {/* Dhikr Selector & Daily Goal Config for Active Counter */}
        <section className="min-w-0 lg:col-span-5 space-y-5">
          <div className="rounded-3xl border border-violet-300/20 bg-[#150f44]/80 p-5 shadow-xl">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-amber-300" />
              <span>تغيير نص الذكر لهذا العداد</span>
            </h3>
            <div className="mt-3 space-y-2.5">
              {DHIKR_PRESETS.map((item) => {
                const selected = item.text === activeCounter.dhikrText;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectDhikr(item.text)}
                    className={`btn-glow w-full rounded-2xl border p-3.5 text-right transition-colors ${
                      selected
                        ? 'border-amber-300/60 bg-gradient-to-l from-violet-600/45 to-blue-700/45 text-white'
                        : 'border-white/10 bg-white/5 text-slate-200 hover:bg-white/10'
                    }`}
                  >
                    <p className="text-sm font-bold leading-relaxed">{item.text}</p>
                    <p className="mt-1 text-xs text-slate-300">{item.reward}</p>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="rounded-3xl border border-blue-300/20 bg-[#13134a]/80 p-5 shadow-xl">
            <h3 className="text-base font-bold text-white">هدف {activeCounter.name}</h3>
            <div className="mt-3 grid grid-cols-4 gap-2">
              {GOAL_PRESETS.map((goal) => (
                <button
                  key={goal}
                  type="button"
                  onClick={() => handleSetGoal(goal)}
                  className={`btn-glow min-h-[44px] rounded-xl border font-mono-num text-sm font-bold ${
                    activeCounter.dailyGoal === goal
                      ? 'border-amber-300 bg-gradient-to-l from-violet-600 to-blue-600 text-white'
                      : 'border-white/15 bg-white/5 text-slate-200 hover:bg-white/10'
                  }`}
                >
                  {goal}
                </button>
              ))}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const parsed = Number(customGoalInput);
                if (parsed > 0) {
                  handleSetGoal(parsed);
                  setCustomGoalInput('');
                }
              }}
              className="mt-3 flex gap-2 min-w-0"
            >
              <input
                type="number"
                min={1}
                max={100000}
                value={customGoalInput}
                onChange={(e) => setCustomGoalInput(e.target.value)}
                placeholder="هدف مخصص (مثلاً 500)"
                className="min-h-[44px] min-w-0 flex-1 rounded-xl border border-white/15 bg-white/5 px-3 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-400"
              />
              <button
                type="submit"
                className="btn-glow min-h-[44px] rounded-xl bg-violet-600 px-4 text-sm font-bold text-white whitespace-nowrap shrink-0"
              >
                تعيين
              </button>
            </form>
          </div>
        </section>
      </div>

      {/* Add / Edit Custom Counter Modal */}
      <AnimatePresence>
        {editorOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ scale: 0.94, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.94, opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="w-full max-w-md rounded-3xl border border-violet-300/35 bg-gradient-to-br from-[#211056] via-[#19124a] to-[#0e1f56] p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between gap-3">
                <h3 className="text-lg font-extrabold text-white">
                  {editingCounterId ? 'تعديل عداد التسبيح' : 'إضافة عداد تسبيح جديد'}
                </h3>
                <button
                  type="button"
                  onClick={() => setEditorOpen(false)}
                  aria-label="إغلاق"
                  className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-slate-200 hover:bg-white/20"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleSaveCounterForm} className="mt-4 space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-200 mb-1.5">
                    اسم العداد
                  </label>
                  <input
                    type="text"
                    value={formName}
                    onChange={(e) => {
                      setFormName(e.target.value);
                      setFormError(null);
                    }}
                    placeholder="مثال: عداد للصلوات على النبي"
                    className="min-h-[46px] w-full rounded-xl border border-white/20 bg-white/5 px-3.5 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-200 mb-1.5">
                    نص الذكر أو التسبيح
                  </label>
                  <textarea
                    rows={2}
                    value={formDhikr}
                    onChange={(e) => setFormDhikr(e.target.value)}
                    placeholder="مثال: اللهم صلّ وسلم وبارك على نبينا محمد ﷺ (يُستخدم اسم العداد إذا تُرك فارغاً)"
                    className="w-full rounded-xl border border-white/20 bg-white/5 p-3 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-200 mb-1.5">
                    الهدف اليومي لهذا العداد
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={100000}
                    value={formGoal}
                    onChange={(e) => setFormGoal(e.target.value)}
                    className="min-h-[46px] w-full rounded-xl border border-white/20 bg-white/5 px-3.5 font-mono-num text-sm text-white focus:outline-none focus:ring-2 focus:ring-violet-400"
                  />
                </div>

                {formError && (
                  <p className="text-xs font-semibold text-rose-300">{formError}</p>
                )}

                <div className="flex gap-3 pt-2">
                  <button
                    type="submit"
                    className="btn-glow min-h-[46px] flex-1 rounded-2xl bg-gradient-to-l from-violet-600 to-blue-600 px-4 text-sm font-bold text-white"
                  >
                    {editingCounterId ? 'حفظ التعديلات' : 'إنشاء العداد'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditorOpen(false)}
                    className="btn-glow min-h-[46px] rounded-2xl border border-white/20 bg-white/10 px-5 text-sm font-semibold text-white"
                  >
                    إلغاء
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Goal Completion Celebration Modal */}
      <AnimatePresence>
        {showGoalCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="w-full max-w-md rounded-3xl border border-amber-300/45 bg-gradient-to-br from-[#25125c] via-[#1c134e] to-[#0f235c] p-6 text-center shadow-2xl"
            >
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-amber-400/20 text-amber-300">
                <Award className="h-9 w-9" />
              </div>
              <h3 className="mt-4 text-2xl font-extrabold text-white">ما شاء الله! بارك الله فيك</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-200">
                أتممت هدف <span className="font-bold text-white">{activeCounter.name}</span> (
                <span className="font-mono-num font-bold text-amber-300">
                  {activeCounter.dailyGoal}
                </span>{' '}
                تسبيحة):
              </p>
              <p className="mt-2 font-quran text-xl font-bold text-amber-200">
                {activeCounter.dhikrText}
              </p>
              <p className="mt-3 text-xs text-slate-300">
                تقبّل الله طاعتك وكتب لك الأجر مضاعفاً
              </p>

              <div className="mt-6 flex flex-col sm:flex-row gap-3">
                <button
                  type="button"
                  onClick={() => setShowGoalCelebration(false)}
                  className="btn-glow min-h-[46px] flex-1 flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-violet-600 to-blue-600 px-4 py-2.5 text-sm font-bold text-white"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  <span>متابعة التسبيح</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowGoalCelebration(false);
                    commitCounterUpdate({ ...activeCounter, currentCount: 0 });
                  }}
                  className="btn-glow min-h-[46px] flex-1 rounded-2xl border border-white/20 bg-white/10 px-4 py-2.5 text-sm font-semibold text-white"
                >
                  دورة جديدة (من الصفر)
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
