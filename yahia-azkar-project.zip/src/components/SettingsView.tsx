import React, { useState } from 'react';
import { Capacitor } from '@capacitor/core';
import {
  Bell,
  FolderArchive,
  Info,
  MapPin,
  Smartphone,
  Vibrate,
  Volume2,
} from 'lucide-react';
import { CITIES } from '../utils/prayerTimes';
import {
  playReminderAudio,
  requestNotificationPermission,
  stopReminderAudio,
  triggerHaptic,
} from '../utils/reminderAudio';
import type { AppSettings, ReminderConfig } from '../utils/storage';
import { APP_COVER_IMAGE } from './AppFooter';
import { PWAInstallButton } from './PWAInstallButton';

interface SettingsViewProps {
  settings: AppSettings;
  reminder: ReminderConfig;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  onUpdateReminder: (next: ReminderConfig) => void;
  onNavigateReminders: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  reminder,
  onUpdateSettings,
  onUpdateReminder,
  onNavigateReminders,
}) => {
  const [imgError, setImgError] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [zipMessage, setZipMessage] = useState<string | null>(null);
  const [isTestingAudio, setIsTestingAudio] = useState(false);
  const isNative = Capacitor.isNativePlatform();

  const handleToggleTestAudio = async () => {
    if (isTestingAudio) {
      stopReminderAudio();
      setIsTestingAudio(false);
      return;
    }
    setIsTestingAudio(true);
    const ok = await playReminderAudio(reminder.soundVolume, () => {
      setIsTestingAudio(false);
    });
    if (!ok) {
      setIsTestingAudio(false);
    }
  };

  const handleDownloadProjectZip = async () => {
    if (downloadingZip) return;
    setDownloadingZip(true);
    setZipMessage(null);
    try {
      const res = await fetch('/api/download-project-zip');
      if (!res.ok) throw new Error('failed');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'yahia-azkar-project.zip';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      setZipMessage('بدأ تحميل ملف yahia-azkar-project.zip إلى جهازك');
    } catch {
      setZipMessage('تعذر تحميل الملف — افتح الرابط في متصفح Chrome وجرّب مرة أخرى');
    } finally {
      setDownloadingZip(false);
    }
  };

  return (
    <div className="w-full min-w-0 space-y-6">
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Notifications & Audio Settings */}
        <section className="min-w-0 rounded-3xl border border-violet-300/20 bg-[#150f44]/85 p-5 sm:p-6 shadow-xl space-y-4">
          <h2 className="text-lg font-extrabold text-white flex items-center gap-2">
            <Bell className="h-5 w-5 text-amber-300" />
            <span>التحكم في التنبيهات والصوت</span>
          </h2>

          <label className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/5 p-3.5 cursor-pointer">
            <div>
              <p className="text-sm font-bold text-white">تفعيل تنبيهات النظام</p>
              <p className="text-xs text-slate-300">إظهار إشعارات الأذكار عند إغلاق التطبيق</p>
            </div>
            <input
              type="checkbox"
              checked={settings.notificationsEnabled}
              onChange={(e) => {
                const enabled = e.target.checked;
                if (enabled) {
                  void requestNotificationPermission();
                }
                onUpdateSettings({ notificationsEnabled: enabled });
                if (!enabled && reminder.enabled) {
                  onUpdateReminder({ ...reminder, enabled: false, nextTriggerAt: null });
                }
              }}
              className="h-5 w-5 accent-violet-500"
            />
          </label>

          <label className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/5 p-3.5 cursor-pointer">
            <div>
              <p className="text-sm font-bold text-white">صوت التذكير الناطق</p>
              <p className="text-xs text-slate-300">تشغيل مقطع الذكر الصوتي مع التذكير</p>
            </div>
            <input
              type="checkbox"
              checked={reminder.soundEnabled}
              onChange={(e) =>
                onUpdateReminder({ ...reminder, soundEnabled: e.target.checked })
              }
              className="h-5 w-5 accent-violet-500"
            />
          </label>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-3.5">
            <div className="flex items-center justify-between text-xs font-bold text-white mb-2">
              <span className="flex items-center gap-1.5">
                <Volume2 className="h-4 w-4 text-blue-300" />
                <span>مستوى صوت التذكير</span>
              </span>
              <span className="font-mono-num text-amber-300">
                {Math.round(reminder.soundVolume * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0.1}
              max={1}
              step={0.05}
              value={reminder.soundVolume}
              onChange={(e) =>
                onUpdateReminder({ ...reminder, soundVolume: Number(e.target.value) })
              }
              className="w-full accent-violet-500"
            />
            <button
              type="button"
              onClick={() => void handleToggleTestAudio()}
              className="btn-glow mt-3 min-h-[40px] rounded-xl border border-white/15 bg-white/10 px-4 text-xs font-bold text-white"
            >
              {isTestingAudio ? 'إيقاف صوت التجربة' : 'اختبار مستوى الصوت (قناة الإشعارات)'}
            </button>
          </div>

          <button
            type="button"
            onClick={onNavigateReminders}
            className="btn-glow min-h-[46px] w-full rounded-2xl bg-gradient-to-l from-violet-600 to-blue-600 px-4 py-2.5 text-sm font-bold text-white"
          >
            فتح إعدادات مواعيد التذكير المتقدمة
          </button>
        </section>

        {/* Vibration & Prayer Location */}
        <section className="min-w-0 space-y-6">
          <div className="rounded-3xl border border-blue-300/20 bg-[#14124a]/85 p-5 sm:p-6 shadow-xl space-y-4">
            <h2 className="text-lg font-extrabold text-white flex items-center gap-2">
              <Vibrate className="h-5 w-5 text-violet-300" />
              <span>التحكم في الاهتزاز</span>
            </h2>

            <label className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/5 p-3.5 cursor-pointer">
              <div>
                <p className="text-sm font-bold text-white">اهتزاز خفيف عند التسبيح</p>
                <p className="text-xs text-slate-300">استجابة لمسية عند الضغط على عداد الأذكار</p>
              </div>
              <input
                type="checkbox"
                checked={settings.tapVibration}
                onChange={(e) => onUpdateSettings({ tapVibration: e.target.checked })}
                className="h-5 w-5 accent-violet-500"
              />
            </label>

            <label className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/5 p-3.5 cursor-pointer">
              <div>
                <p className="text-sm font-bold text-white">اهتزاز عند إكمال الهدف اليومي</p>
                <p className="text-xs text-slate-300">نبضة تهنئة عند الوصول لهدف الأذكار</p>
              </div>
              <input
                type="checkbox"
                checked={settings.goalVibration}
                onChange={(e) => onUpdateSettings({ goalVibration: e.target.checked })}
                className="h-5 w-5 accent-violet-500"
              />
            </label>

            <button
              type="button"
              onClick={() => triggerHaptic([35, 60, 35])}
              className="btn-glow min-h-[44px] rounded-xl border border-white/15 bg-white/10 px-4 text-xs font-bold text-white"
            >
              تجربة الاهتزاز الآن
            </button>
          </div>

          <div className="rounded-3xl border border-violet-300/20 bg-[#150f44]/85 p-5 sm:p-6 shadow-xl space-y-3">
            <h2 className="text-base font-extrabold text-white flex items-center gap-2">
              <MapPin className="h-5 w-5 text-amber-300" />
              <span>المدينة لحساب مواقيت الصلاة</span>
            </h2>
            <select
              aria-label="المدينة لمواقيت الصلاة"
              value={settings.cityId}
              onChange={(e) =>
                onUpdateSettings({ cityId: e.target.value, customCoords: null })
              }
              className="min-h-[46px] w-full rounded-xl border border-white/15 bg-[#1b1255] px-3.5 text-sm font-semibold text-white focus:outline-none focus:ring-2 focus:ring-violet-400"
            >
              {CITIES.map((city) => (
                <option key={city.id} value={city.id}>
                  {city.nameAr} — {city.countryAr}
                </option>
              ))}
            </select>
          </div>
        </section>
      </div>

      {/* PWA Install & App Info */}
      <section className="rounded-3xl border border-violet-300/20 bg-gradient-to-br from-[#1b1150]/85 to-[#0d1c50]/85 p-5 sm:p-6 shadow-xl">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            {!imgError ? (
              <img
                src={APP_COVER_IMAGE}
                alt="صورة تطبيق صلى على الحبيب"
                referrerPolicy="no-referrer"
                onError={() => setImgError(true)}
                className="h-20 w-20 shrink-0 rounded-2xl border border-amber-300/40 object-cover shadow-lg"
              />
            ) : (
              <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl border border-amber-300/40 bg-violet-900">
                <Smartphone className="h-8 w-8 text-amber-300" />
              </div>
            )}
            <div>
              <p className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
                <Info className="h-4 w-4" />
                <span>معلومات عن التطبيق</span>
              </p>
              <h3 className="mt-1 text-lg font-extrabold text-white">
                {'{𝐘𝐀𝐇𝐈𝐀}'}صلـى عـلى الـحـبيـب♥✨
              </h3>
              <p className="mt-1 text-xs leading-relaxed text-slate-300">
                تطبيق إسلامي شامل للذكر والتسبيح ومواقيت الصلاة والقرآن الكريم مع تذكير صوتي مستمر وإشعارات مجدولة.
              </p>
            </div>
          </div>

          <div className="sm:w-56 shrink-0">
            <PWAInstallButton />
          </div>
        </div>
      </section>

      {!isNative && (
        <section className="rounded-3xl border border-blue-300/20 bg-gradient-to-br from-[#14124a]/85 to-[#0b1f54]/85 p-5 sm:p-6 shadow-xl">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3.5">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-violet-600/30 text-amber-300">
                <FolderArchive className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white">
                  تصدير ملفات المشروع كاملة (.zip) لبناء APK
                </h3>
                <p className="mt-1 text-xs leading-relaxed text-slate-300">
                  يحمل ملف مضغوط فيه الكود بالكامل + مجلد الأندرويد + ملف بناء GitHub Actions لرفعه على GitHub واستخراج ملف APK.
                </p>
                {zipMessage && (
                  <p className="mt-2 text-xs font-semibold text-emerald-300">{zipMessage}</p>
                )}
              </div>
            </div>

            <button
              type="button"
              onClick={() => void handleDownloadProjectZip()}
              disabled={downloadingZip}
              className="btn-glow min-h-[48px] flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-violet-600 to-blue-600 px-5 py-2.5 text-sm font-bold text-white shadow-lg disabled:opacity-60 whitespace-nowrap shrink-0"
            >
              <FolderArchive className="h-4 w-4 shrink-0" />
              <span>{downloadingZip ? 'جاري التجهيز...' : 'تحميل المشروع ZIP'}</span>
            </button>
          </div>
        </section>
      )}
    </div>
  );
};
