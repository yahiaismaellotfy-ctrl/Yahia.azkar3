import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  BookOpen,
  Check,
  Copy,
  DownloadCloud,
  HeartHandshake,
  Minus,
  Plus,
  RotateCcw,
  Search,
} from 'lucide-react';
import { AZKAR_CATEGORIES, type AzkarCategory } from '../data/azkarData';
import {
  downloadFullQuranOffline,
  fetchSurahAyahs,
  SURAHS_META,
  type SurahAyah,
  type SurahMeta,
  toArabicNumerals,
} from '../data/quranData';
import { triggerHaptic } from '../utils/reminderAudio';
import { getCachedSurahCount, type AppSettings } from '../utils/storage';

interface QuranAzkarViewProps {
  settings: AppSettings;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
}

export const QuranAzkarView: React.FC<QuranAzkarViewProps> = ({
  settings,
  onUpdateSettings,
}) => {
  const [section, setSection] = useState<'quran' | 'azkar'>('quran');

  // Quran state
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSurah, setActiveSurah] = useState<SurahMeta | null>(null);
  const [ayahs, setAyahs] = useState<SurahAyah[]>([]);
  const [loadingSurah, setLoadingSurah] = useState(false);
  const [surahError, setSurahError] = useState<string | null>(null);
  const [cachedCount, setCachedCount] = useState(0);
  const [downloadingAll, setDownloadingAll] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState({ done: 0, total: 114 });

  // Azkar state
  const [azkarTab, setAzkarTab] = useState<AzkarCategory['id']>('morning');
  const [remainingMap, setRemainingMap] = useState<Record<string, number>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    void getCachedSurahCount().then(setCachedCount);
  }, []);

  const filteredSurahs = useMemo(() => {
    const q = searchQuery.trim();
    if (!q) return SURAHS_META;
    return SURAHS_META.filter(
      (s) => s.name.includes(q) || String(s.number) === q
    );
  }, [searchQuery]);

  const openSurah = async (surah: SurahMeta) => {
    setActiveSurah(surah);
    setLoadingSurah(true);
    setSurahError(null);
    onUpdateSettings({ lastReadSurah: surah.number });

    try {
      const data = await fetchSurahAyahs(surah.number);
      setAyahs(data);
      const count = await getCachedSurahCount();
      setCachedCount(count);
    } catch (err) {
      setSurahError(
        err instanceof Error ? err.message : 'تعذر تحميل السورة، تحقق من الاتصال'
      );
    } finally {
      setLoadingSurah(false);
    }
  };

  const handleDownloadAllQuran = async () => {
    if (downloadingAll) return;
    setDownloadingAll(true);
    setSurahError(null);
    try {
      await downloadFullQuranOffline((done, total) => {
        setDownloadProgress({ done, total });
      });
      const count = await getCachedSurahCount();
      setCachedCount(count);
    } catch {
      setSurahError('تعذر تحميل المصحف بالكامل — تأكد من اتصالك بالإنترنت');
    } finally {
      setDownloadingAll(false);
    }
  };

  const activeAzkarCategory = useMemo(
    () => AZKAR_CATEGORIES.find((c) => c.id === azkarTab) || AZKAR_CATEGORIES[0],
    [azkarTab]
  );

  const getRemaining = (id: string, defaultRepeat: number) =>
    remainingMap[id] ?? defaultRepeat;

  const handleAzkarTap = (id: string, defaultRepeat: number) => {
    const cur = getRemaining(id, defaultRepeat);
    if (cur <= 0) return;
    if (settings.tapVibration) {
      triggerHaptic(cur === 1 ? [30, 50, 30] : 18);
    }
    setRemainingMap((prev) => ({ ...prev, [id]: cur - 1 }));
  };

  const handleResetCategory = () => {
    const next = { ...remainingMap };
    for (const item of activeAzkarCategory.items) {
      delete next[item.id];
    }
    setRemainingMap(next);
  };

  const handleCopyText = async (id: string, text: string) => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
      } else {
        throw new Error('fallback');
      }
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1800);
    } catch {
      try {
        const el = document.createElement('textarea');
        el.value = text;
        el.setAttribute('readonly', '');
        el.style.position = 'fixed';
        el.style.opacity = '0';
        document.body.appendChild(el);
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
        setCopiedId(id);
        setTimeout(() => setCopiedId(null), 1800);
      } catch {
        // Ignore copy failure
      }
    }
  };

  const readerThemeClasses =
    settings.quranTheme === 'parchment'
      ? 'bg-[#f6eedb] text-[#2a1f14] border-[#d9c7a3]'
      : settings.quranTheme === 'midnight'
      ? 'bg-[#0a1636] text-[#e6eefc] border-blue-400/25'
      : 'bg-[#170e3f] text-[#f5f3ff] border-violet-300/25';

  const lastReadMeta =
    SURAHS_META.find((s) => s.number === settings.lastReadSurah) || SURAHS_META[0];

  return (
    <div className="w-full min-w-0 space-y-6">
      {/* Main Sub-navigation: Quran vs Azkar */}
      <div className="flex items-center gap-2 rounded-2xl border border-violet-300/20 bg-[#140d3f]/80 p-1.5">
        <button
          type="button"
          onClick={() => setSection('quran')}
          className={`btn-glow flex-1 min-h-[46px] flex items-center justify-center gap-2 rounded-xl text-sm font-bold transition-colors ${
            section === 'quran'
              ? 'bg-gradient-to-l from-violet-600 to-blue-600 text-white shadow-lg'
              : 'text-slate-300 hover:text-white'
          }`}
        >
          <BookOpen className="h-4 w-4 shrink-0" />
          <span>القرآن الكريم</span>
        </button>

        <button
          type="button"
          onClick={() => setSection('azkar')}
          className={`btn-glow flex-1 min-h-[46px] flex items-center justify-center gap-2 rounded-xl text-sm font-bold transition-colors ${
            section === 'azkar'
              ? 'bg-gradient-to-l from-violet-600 to-blue-600 text-white shadow-lg'
              : 'text-slate-300 hover:text-white'
          }`}
        >
          <HeartHandshake className="h-4 w-4 shrink-0" />
          <span>الأدعية والأذكار</span>
        </button>
      </div>

      {/* SECTION 1: QURAN */}
      {section === 'quran' && (
        <div className="space-y-5">
          {!activeSurah ? (
            <>
              {/* Quick Actions & Offline Download Bar */}
              <div className="rounded-3xl border border-violet-300/20 bg-[#150f44]/80 p-5 shadow-xl space-y-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <h2 className="text-lg font-extrabold text-white">المصحف الشريف</h2>
                    <p className="text-xs text-slate-300">
                      متاح ١١٤ سورة بالرسم العثماني · السور المحفوظة بدون نت:{' '}
                      <span className="font-mono-num font-bold text-amber-300">{cachedCount}/114</span>
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => void openSurah(lastReadMeta)}
                      className="btn-glow min-h-[44px] rounded-xl border border-amber-300/35 bg-amber-500/20 px-4 py-2 text-xs font-bold text-amber-200 whitespace-nowrap shrink-0"
                    >
                      متابعة: سورة {lastReadMeta.name}
                    </button>

                    <button
                      type="button"
                      onClick={() => void handleDownloadAllQuran()}
                      disabled={downloadingAll}
                      className="btn-glow min-h-[44px] flex items-center gap-2 rounded-xl bg-gradient-to-l from-violet-600 to-blue-600 px-4 py-2 text-xs font-bold text-white disabled:opacity-60 whitespace-nowrap shrink-0"
                    >
                      <DownloadCloud className="h-4 w-4 shrink-0" />
                      <span>
                        {downloadingAll
                          ? `جاري الحفظ ${downloadProgress.done}/${downloadProgress.total}...`
                          : 'حفظ المصحف كاملاً بدون نت'}
                      </span>
                    </button>
                  </div>
                </div>

                {/* Search Surahs */}
                <div className="relative">
                  <Search className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    type="search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث باسم السورة أو رقمها (مثال: الكهف، يس، الملك)..."
                    className="min-h-[46px] w-full rounded-2xl border border-white/15 bg-white/5 pr-10 pl-4 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-400"
                  />
                </div>
              </div>

              {surahError && (
                <p className="rounded-2xl border border-rose-400/30 bg-rose-950/50 p-4 text-xs font-semibold text-rose-200">
                  {surahError}
                </p>
              )}

              {/* Surahs Grid */}
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {filteredSurahs.map((surah) => (
                  <button
                    key={surah.number}
                    type="button"
                    onClick={() => void openSurah(surah)}
                    className="btn-glow flex items-center justify-between rounded-2xl border border-white/10 bg-[#17114b]/75 p-4 text-right hover:border-violet-400/45"
                  >
                    <div className="flex items-center gap-3.5">
                      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-amber-300/35 bg-gradient-to-br from-violet-700/60 to-blue-800/60 font-mono-num text-sm font-bold text-amber-200">
                        {surah.number}
                      </span>
                      <div>
                        <h3 className="font-quran text-xl font-bold text-white">سورة {surah.name}</h3>
                        <p className="text-xs text-slate-300">
                          {surah.revelationType} · <span className="font-mono-num">{surah.ayahCount}</span> آية
                        </p>
                      </div>
                    </div>
                    <span className="text-xs font-semibold text-violet-300">قراءة ←</span>
                  </button>
                ))}
              </div>
            </>
          ) : (
            /* Surah Eye-Comfort Reader */
            <div className="space-y-4">
              {/* Reader Toolbar */}
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-violet-300/20 bg-[#150f44]/85 p-3.5">
                <button
                  type="button"
                  onClick={() => setActiveSurah(null)}
                  className="btn-glow min-h-[44px] flex items-center gap-2 rounded-xl border border-white/15 bg-white/10 px-4 py-2 text-xs font-bold text-white"
                >
                  <ArrowRight className="h-4 w-4" />
                  <span>فهرس السور</span>
                </button>

                <div className="flex flex-wrap items-center gap-2">
                  {/* Eye-Comfort Theme Switcher */}
                  <div className="flex items-center gap-1 rounded-xl bg-black/25 p-1">
                    {(
                      [
                        { id: 'royal', label: 'ملكي' },
                        { id: 'parchment', label: 'ورق دافئ' },
                        { id: 'midnight', label: 'ليلي هادئ' },
                      ] as const
                    ).map((theme) => (
                      <button
                        key={theme.id}
                        type="button"
                        onClick={() => onUpdateSettings({ quranTheme: theme.id })}
                        className={`min-h-[36px] rounded-lg px-2.5 text-xs font-bold transition-colors ${
                          settings.quranTheme === theme.id
                            ? 'bg-violet-600 text-white'
                            : 'text-slate-300 hover:text-white'
                        }`}
                      >
                        {theme.label}
                      </button>
                    ))}
                  </div>

                  {/* Font Size Controls */}
                  <div className="flex items-center gap-1 rounded-xl bg-black/25 p-1">
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateSettings({ quranFontSize: Math.max(18, settings.quranFontSize - 2) })
                      }
                      className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-200 hover:bg-white/10"
                      aria-label="تصغير الخط"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="px-2 font-mono-num text-xs font-bold text-amber-300">
                      {settings.quranFontSize}
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateSettings({ quranFontSize: Math.min(40, settings.quranFontSize + 2) })
                      }
                      className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-200 hover:bg-white/10"
                      aria-label="تكبير الخط"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Reader Canvas */}
              <article
                className={`rounded-3xl border p-6 sm:p-10 shadow-2xl transition-colors ${readerThemeClasses}`}
              >
                <header className="border-b border-current/15 pb-5 text-center">
                  <p className="text-xs font-semibold opacity-75">
                    {activeSurah.revelationType} · {activeSurah.ayahCount} آية
                  </p>
                  <h2 className="mt-1 font-quran text-3xl sm:text-4xl font-bold">
                    سورة {activeSurah.name}
                  </h2>
                  {activeSurah.number !== 1 && activeSurah.number !== 9 && (
                    <p className="mt-4 font-quran text-2xl sm:text-3xl opacity-90">
                      بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                    </p>
                  )}
                </header>

                {loadingSurah ? (
                  <div className="py-16 text-center text-sm opacity-80">
                    جاري تحميل آيات سورة {activeSurah.name}...
                  </div>
                ) : surahError ? (
                  <div className="py-12 text-center space-y-3">
                    <p className="text-sm font-bold text-rose-400">{surahError}</p>
                    <button
                      type="button"
                      onClick={() => void openSurah(activeSurah)}
                      className="btn-glow rounded-xl bg-violet-600 px-5 py-2.5 text-xs font-bold text-white"
                    >
                      إعادة المحاولة
                    </button>
                  </div>
                ) : (
                  <div
                    className="mt-6 font-quran text-justify leading-[2.35]"
                    style={{ fontSize: `${settings.quranFontSize}px` }}
                  >
                    {ayahs.map((ayah) => (
                      <span key={ayah.numberInSurah} className="inline">
                        {ayah.text}{' '}
                        <span className="mx-1.5 inline-flex items-center justify-center font-sans text-[0.7em] font-bold text-amber-500">
                          ﴿{toArabicNumerals(ayah.numberInSurah)}﴾
                        </span>{' '}
                      </span>
                    ))}
                  </div>
                )}
              </article>
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: AZKAR & DUAS */}
      {section === 'azkar' && (
        <div className="space-y-5 min-w-0">
          {/* Azkar Category Tabs */}
          <div className="flex flex-wrap gap-2">
            {AZKAR_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setAzkarTab(cat.id)}
                className={`btn-glow min-h-[44px] rounded-2xl border px-4 py-2 text-xs sm:text-sm font-bold whitespace-nowrap shrink-0 ${
                  azkarTab === cat.id
                    ? 'border-amber-300/60 bg-gradient-to-l from-violet-600 to-blue-600 text-white'
                    : 'border-white/15 bg-white/5 text-slate-300 hover:bg-white/10'
                }`}
              >
                {cat.title}
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-extrabold text-white">{activeAzkarCategory.title}</h2>
              <p className="text-xs text-slate-300">{activeAzkarCategory.subtitle}</p>
            </div>
            <button
              type="button"
              onClick={handleResetCategory}
              className="btn-glow min-h-[40px] flex items-center gap-1.5 rounded-xl border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-semibold text-slate-200"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>إعادة ضبط</span>
            </button>
          </div>

          <div className="space-y-4">
            {activeAzkarCategory.items.map((item) => {
              const remaining = getRemaining(item.id, item.repeat);
              const done = remaining <= 0;

              return (
                <div
                  key={item.id}
                  className={`rounded-3xl border p-5 transition-colors ${
                    done
                      ? 'border-emerald-400/40 bg-emerald-950/35'
                      : 'border-violet-300/20 bg-[#150f44]/85'
                  }`}
                >
                  <p className="font-quran text-xl sm:text-2xl leading-[2.0] text-white">
                    {item.text}
                  </p>
                  <p className="mt-2 text-xs text-amber-200/90">{item.virtue}</p>

                  <div className="mt-4 flex items-center justify-between gap-3 border-t border-white/10 pt-3">
                    <button
                      type="button"
                      onClick={() => handleAzkarTap(item.id, item.repeat)}
                      disabled={done}
                      className={`btn-glow min-h-[44px] flex items-center gap-2 rounded-xl px-4 py-2 text-xs sm:text-sm font-bold ${
                        done
                          ? 'bg-emerald-600/35 text-emerald-200'
                          : 'bg-gradient-to-l from-violet-600 to-blue-600 text-white'
                      }`}
                    >
                      {done ? (
                        <>
                          <Check className="h-4 w-4" />
                          <span>تم الذكر</span>
                        </>
                      ) : (
                        <>
                          <span>التكرار المتبقي:</span>
                          <span className="font-mono-num text-base text-amber-200">{remaining}</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => void handleCopyText(item.id, item.text)}
                      className="btn-glow min-h-[44px] flex items-center gap-1.5 rounded-xl border border-white/15 bg-white/5 px-3.5 py-2 text-xs font-semibold text-slate-200"
                    >
                      {copiedId === item.id ? (
                        <>
                          <Check className="h-4 w-4 text-emerald-300" />
                          <span>تم النسخ</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-4 w-4" />
                          <span>نسخ</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
