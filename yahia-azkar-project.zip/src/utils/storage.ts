export interface CustomTasbeehCounter {
  id: string;
  name: string;
  dhikrText: string;
  currentCount: number;
  dailyGoal: number;
  totalCount: number;
  completedRounds: number;
  createdAt: number;
}

export interface TasbeehState {
  currentCount: number;
  dailyGoal: number;
  totalLifetimeCount: number;
  completedRounds: number;
  selectedDhikr: string;
  lastUpdatedDate: string; // YYYY-MM-DD
  activeCounterId: string;
  counters: CustomTasbeehCounter[];
}

export interface ReminderConfig {
  enabled: boolean;
  intervalMinutes: number;
  selectedDhikr: string;
  customDhikr: string;
  nextTriggerAt: number | null;
  soundEnabled: boolean;
  soundVolume: number; // 0 to 1
  vibrateEnabled: boolean;
  quietHoursEnabled: boolean;
  quietStartHour: number; // e.g. 23
  quietEndHour: number; // e.g. 5
  backgroundKeepAlive: boolean;
}

export interface AppSettings {
  tapVibration: boolean;
  goalVibration: boolean;
  notificationsEnabled: boolean;
  cityId: string;
  customCoords: { lat: number; lng: number; label: string } | null;
  quranFontSize: number;
  quranTheme: 'royal' | 'parchment' | 'midnight';
  lastReadSurah: number;
}

export const DEFAULT_COUNTERS: CustomTasbeehCounter[] = [
  {
    id: 'salawat-counter',
    name: 'عداد الصلوات على النبي',
    dhikrText: 'اللهم صلّ وسلم وبارك على نبينا محمد ﷺ',
    currentCount: 0,
    dailyGoal: 100,
    totalCount: 0,
    completedRounds: 0,
    createdAt: 1,
  },
  {
    id: 'morning-azkar-counter',
    name: 'عداد أذكار الصباح',
    dhikrText: 'سبحان الله وبحمده، سبحان الله العظيم',
    currentCount: 0,
    dailyGoal: 100,
    totalCount: 0,
    completedRounds: 0,
    createdAt: 2,
  },
  {
    id: 'istighfar-counter',
    name: 'عداد الاستغفار',
    dhikrText: 'أستغفر الله العظيم الذي لا إله إلا هو الحي القيوم وأتوب إليه',
    currentCount: 0,
    dailyGoal: 100,
    totalCount: 0,
    completedRounds: 0,
    createdAt: 3,
  },
];

export const DEFAULT_TASBEEH_STATE: TasbeehState = {
  currentCount: 0,
  dailyGoal: 100,
  totalLifetimeCount: 0,
  completedRounds: 0,
  selectedDhikr: DEFAULT_COUNTERS[0].dhikrText,
  lastUpdatedDate: new Date().toISOString().slice(0, 10),
  activeCounterId: DEFAULT_COUNTERS[0].id,
  counters: DEFAULT_COUNTERS,
};

export function normalizeTasbeehState(raw: Partial<TasbeehState> | null | undefined): TasbeehState {
  if (!raw) return DEFAULT_TASBEEH_STATE;
  const hasCounters = Array.isArray(raw.counters) && raw.counters.length > 0;
  if (!hasCounters) {
    const migratedCounter: CustomTasbeehCounter = {
      ...DEFAULT_COUNTERS[0],
      dhikrText: raw.selectedDhikr || DEFAULT_COUNTERS[0].dhikrText,
      currentCount: raw.currentCount ?? 0,
      dailyGoal: raw.dailyGoal ?? 100,
      totalCount: raw.totalLifetimeCount ?? raw.currentCount ?? 0,
      completedRounds: raw.completedRounds ?? 0,
    };
    const counters = [migratedCounter, ...DEFAULT_COUNTERS.slice(1)];
    return {
      ...DEFAULT_TASBEEH_STATE,
      ...raw,
      activeCounterId: migratedCounter.id,
      counters,
    };
  }

  const counters = raw.counters!;
  const active = counters.find((c) => c.id === raw.activeCounterId) || counters[0];
  return {
    ...DEFAULT_TASBEEH_STATE,
    ...raw,
    activeCounterId: active.id,
    counters,
    currentCount: active.currentCount,
    dailyGoal: active.dailyGoal,
    selectedDhikr: active.dhikrText,
    completedRounds: active.completedRounds,
    totalLifetimeCount:
      raw.totalLifetimeCount ??
      counters.reduce((sum, c) => sum + (c.totalCount || 0), 0),
  };
}

export const DEFAULT_REMINDER_CONFIG: ReminderConfig = {
  enabled: false,
  intervalMinutes: 15,
  selectedDhikr: 'صلّ على الحبيب محمد ﷺ — سبحان الله والحمد لله والله أكبر',
  customDhikr: '',
  nextTriggerAt: null,
  soundEnabled: true,
  soundVolume: 0.9,
  vibrateEnabled: true,
  quietHoursEnabled: false,
  quietStartHour: 23,
  quietEndHour: 5,
  backgroundKeepAlive: true,
};

export const DEFAULT_SETTINGS: AppSettings = {
  tapVibration: true,
  goalVibration: true,
  notificationsEnabled: true,
  cityId: 'cairo',
  customCoords: null,
  quranFontSize: 24,
  quranTheme: 'royal',
  lastReadSurah: 1,
};

const DB_NAME = 'yahia-distrova-db';
const DB_VERSION = 1;
const STORE_KV = 'kv';
const STORE_QURAN = 'quran_surahs';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_KV)) {
        db.createObjectStore(STORE_KV);
      }
      if (!db.objectStoreNames.contains(STORE_QURAN)) {
        db.createObjectStore(STORE_QURAN);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function idbGet<T>(key: string, storeName = STORE_KV): Promise<T | null> {
  try {
    const db = await openDB();
    return await new Promise((resolve) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const req = store.get(key);
      req.onsuccess = () => resolve((req.result as T) ?? null);
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

export async function idbSet<T>(key: string, value: T, storeName = STORE_KV): Promise<void> {
  try {
    const db = await openDB();
    await new Promise<void>((resolve) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      store.put(value, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } catch {
    // Fallback handled by localStorage
  }
}

export async function idbCount(storeName = STORE_QURAN): Promise<number> {
  try {
    const db = await openDB();
    return await new Promise((resolve) => {
      const tx = db.transaction(storeName, 'readonly');
      const req = tx.objectStore(storeName).count();
      req.onsuccess = () => resolve(req.result || 0);
      req.onerror = () => resolve(0);
    });
  } catch {
    return 0;
  }
}

export function loadLocalSync<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return { ...fallback, ...JSON.parse(raw) };
  } catch {
    return fallback;
  }
}

export function saveLocalSync<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch {
    // Ignore storage quota errors
  }
}

export async function saveTasbeehPersisted(state: TasbeehState): Promise<void> {
  saveLocalSync('yd_tasbeeh', state);
  await idbSet('tasbeeh', state);
}

export async function loadTasbeehPersisted(): Promise<TasbeehState> {
  const fromIdb = await idbGet<TasbeehState>('tasbeeh');
  const fromLs = loadLocalSync('yd_tasbeeh', DEFAULT_TASBEEH_STATE);
  return normalizeTasbeehState(fromIdb || fromLs);
}

export async function saveReminderConfigPersisted(config: ReminderConfig): Promise<void> {
  saveLocalSync('yd_reminder', config);
  await idbSet('reminderConfig', config);
}

export async function loadReminderConfigPersisted(): Promise<ReminderConfig> {
  const fromIdb = await idbGet<ReminderConfig>('reminderConfig');
  const fromLs = loadLocalSync('yd_reminder', DEFAULT_REMINDER_CONFIG);
  return fromIdb ? { ...DEFAULT_REMINDER_CONFIG, ...fromIdb } : fromLs;
}

export async function saveSettingsPersisted(settings: AppSettings): Promise<void> {
  saveLocalSync('yd_settings', settings);
  await idbSet('appSettings', settings);
}

export async function loadSettingsPersisted(): Promise<AppSettings> {
  const fromIdb = await idbGet<AppSettings>('appSettings');
  const fromLs = loadLocalSync('yd_settings', DEFAULT_SETTINGS);
  return fromIdb ? { ...DEFAULT_SETTINGS, ...fromIdb } : fromLs;
}

export interface CachedSurah {
  number: number;
  ayahs: { numberInSurah: number; text: string }[];
}

export async function getCachedSurah(surahNumber: number): Promise<CachedSurah | null> {
  return idbGet<CachedSurah>(`surah_${surahNumber}`, STORE_QURAN);
}

export async function setCachedSurah(surah: CachedSurah): Promise<void> {
  return idbSet(`surah_${surah.number}`, surah, STORE_QURAN);
}

export async function getCachedSurahCount(): Promise<number> {
  return idbCount(STORE_QURAN);
}
