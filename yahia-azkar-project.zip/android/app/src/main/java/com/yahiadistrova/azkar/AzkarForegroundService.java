package com.yahiadistrova.azkar;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;

public class AzkarForegroundService extends Service {
    public static final String ACTION_START_KEEPALIVE = "com.yahiadistrova.azkar.ACTION_START_KEEPALIVE";
    public static final String ACTION_PLAY_REMINDER = "com.yahiadistrova.azkar.ACTION_PLAY_REMINDER";
    public static final String ACTION_STOP_SOUND = "com.yahiadistrova.azkar.ACTION_STOP_SOUND";
    public static final String ACTION_STOP_ALL = "com.yahiadistrova.azkar.ACTION_STOP_ALL";

    public static final int SERVICE_NOTIF_ID = 7705;

    private static MediaPlayer activePlayer = null;
    private static PowerManager.WakeLock playbackWakeLock = null;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        AzkarAlarmReceiver.ensureNotificationChannel(this);

        String action = intent != null ? intent.getAction() : ACTION_START_KEEPALIVE;
        SharedPreferences prefs = getSharedPreferences(AzkarAlarmReceiver.PREFS_NAME, Context.MODE_PRIVATE);
        boolean enabled = prefs.getBoolean("enabled", false);
        int intervalMinutes = Math.max(1, prefs.getInt("intervalMinutes", 15));
        String phrase = prefs.getString("phrase", "اللهم صلّ وسلم وبارك على نبينا محمد ﷺ");

        if (ACTION_STOP_ALL.equals(action)) {
            stopActiveSound();
            stopForegroundCompat();
            stopSelf();
            return START_NOT_STICKY;
        }

        if (ACTION_STOP_SOUND.equals(action)) {
            stopActiveSound();
            if (!enabled) {
                stopForegroundCompat();
                stopSelf();
                return START_NOT_STICKY;
            }
            startForegroundCompat(buildOngoingNotification(intervalMinutes, phrase));
            return START_STICKY;
        }

        // Always enter foreground immediately to comply with Android 8-16 foreground requirements
        startForegroundCompat(buildOngoingNotification(intervalMinutes, phrase));

        if (ACTION_PLAY_REMINDER.equals(action)) {
            float vol = intent != null ? intent.getFloatExtra("volume", prefs.getFloat("soundVolume", 0.9f)) : 0.9f;
            playReminderAudio(vol, enabled);
        }

        return enabled ? START_STICKY : START_NOT_STICKY;
    }

    private void startForegroundCompat(Notification notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(SERVICE_NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(SERVICE_NOTIF_ID, notification);
        }
    }

    private void stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE);
        } else {
            stopForeground(true);
        }
    }

    private Notification buildOngoingNotification(int intervalMinutes, String phrase) {
        Intent launchIntent = new Intent(this, MainActivity.class);
        launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 1, launchIntent, piFlags);

        String intervalLabel = intervalMinutes >= 60
            ? (intervalMinutes % 60 == 0 ? "كل " + (intervalMinutes / 60) + " ساعة" : "كل " + intervalMinutes + " دقيقة")
            : "كل " + intervalMinutes + " دقيقة";

        return new NotificationCompat.Builder(this, AzkarAlarmReceiver.SERVICE_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_azkar)
            .setColor(0xFF7C3AED)
            .setContentTitle("{𝐘𝐀𝐇𝐈𝐀} صلّى على الحبيب · التذكير نشط")
            .setContentText(intervalLabel + " — " + phrase)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(contentIntent)
            .build();
    }

    private void playReminderAudio(float volume, boolean keepServiceRunning) {
        stopActiveSound();

        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                playbackWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "yahia:AzkarAudioWakeLock");
                playbackWakeLock.acquire(45_000L);
            }

            float clamped = Math.max(0.05f, Math.min(1.0f, volume));
            Uri soundUri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.azkar_reminder);

            MediaPlayer mp = new MediaPlayer();
            // Play directly via USAGE_NOTIFICATION without MediaSession so Power/Volume keys never abort playback
            AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
            mp.setAudioAttributes(attrs);
            mp.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
            mp.setDataSource(getApplicationContext(), soundUri);
            mp.setVolume(clamped, clamped);
            mp.setOnCompletionListener(player -> {
                releasePlayer(player);
                releaseWakeLock();
                SharedPreferences prefs = getSharedPreferences(AzkarAlarmReceiver.PREFS_NAME, Context.MODE_PRIVATE);
                if (!prefs.getBoolean("enabled", false) && !keepServiceRunning) {
                    stopForegroundCompat();
                    stopSelf();
                }
            });
            mp.setOnErrorListener((player, what, extra) -> {
                releasePlayer(player);
                releaseWakeLock();
                return true;
            });
            mp.prepare();
            mp.start();
            activePlayer = mp;
        } catch (Exception e) {
            releaseWakeLock();
            if (!keepServiceRunning) {
                stopForegroundCompat();
                stopSelf();
            }
        }
    }

    private static void releasePlayer(MediaPlayer player) {
        if (player == null) return;
        try {
            player.release();
        } catch (Exception ignored) {
        }
        if (activePlayer == player) {
            activePlayer = null;
        }
    }

    private static void releaseWakeLock() {
        if (playbackWakeLock != null && playbackWakeLock.isHeld()) {
            try {
                playbackWakeLock.release();
            } catch (Exception ignored) {
            }
        }
        playbackWakeLock = null;
    }

    public static void stopActiveSound() {
        if (activePlayer != null) {
            try {
                if (activePlayer.isPlaying()) {
                    activePlayer.stop();
                }
                activePlayer.release();
            } catch (Exception ignored) {
            }
            activePlayer = null;
        }
        releaseWakeLock();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // If user swipes app from Recents ("إغلاق الكل"), preserve the scheduled alarm chain
        SharedPreferences prefs = getSharedPreferences(AzkarAlarmReceiver.PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean("enabled", false)) {
            int intervalMinutes = Math.max(1, prefs.getInt("intervalMinutes", 15));
            long storedNext = prefs.getLong("nextTriggerAt", 0L);
            long now = System.currentTimeMillis();
            long nextTriggerAt = storedNext > now ? storedNext : now + (intervalMinutes * 60_000L);
            prefs.edit().putLong("nextTriggerAt", nextTriggerAt).apply();
            AzkarAlarmReceiver.scheduleNextAlarm(getApplicationContext(), nextTriggerAt);
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        // Do not kill sound or alarms unexpectedly; only release local references if stopped cleanly
        super.onDestroy();
    }
}
