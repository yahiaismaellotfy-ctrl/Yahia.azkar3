package com.yahiadistrova.azkar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import androidx.core.content.ContextCompat;

public class AzkarBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;

        SharedPreferences prefs = context.getSharedPreferences(AzkarAlarmReceiver.PREFS_NAME, Context.MODE_PRIVATE);
        boolean enabled = prefs.getBoolean("enabled", false);
        if (!enabled) return;

        int intervalMinutes = Math.max(1, prefs.getInt("intervalMinutes", 15));
        long storedNext = prefs.getLong("nextTriggerAt", 0L);
        long now = System.currentTimeMillis();
        long nextTriggerAt = storedNext > now ? storedNext : now + (intervalMinutes * 60_000L);

        prefs.edit().putLong("nextTriggerAt", nextTriggerAt).apply();
        AzkarAlarmReceiver.ensureNotificationChannel(context);
        AzkarAlarmReceiver.scheduleNextAlarm(context, nextTriggerAt);

        try {
            Intent svc = new Intent(context, AzkarForegroundService.class);
            svc.setAction(AzkarForegroundService.ACTION_START_KEEPALIVE);
            ContextCompat.startForegroundService(context, svc);
        } catch (Exception ignored) {
            // AlarmManager remains scheduled even if boot FGS is deferred by OEM
        }
    }
}
