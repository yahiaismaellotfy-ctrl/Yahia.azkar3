package com.yahiadistrova.azkar;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.util.Calendar;

public class AzkarAlarmReceiver extends BroadcastReceiver {
    public static final String PREFS_NAME = "azkar_reminder_prefs";
    public static final String CHANNEL_ID = "azkar_notif_channel_v3";
    public static final String SERVICE_CHANNEL_ID = "azkar_fg_service_channel_v1";
    public static final int ALARM_REQUEST_CODE = 7701;
    public static final int NOTIF_ID = 7702;

    @Override
    public void onReceive(Context context, Intent intent) {
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakeLock = null;
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "yahia:AzkarAlarmWakeLock");
            wakeLock.acquire(8000L);
        }

        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            boolean enabled = prefs.getBoolean("enabled", false);
            if (!enabled) {
                return;
            }

            int intervalMinutes = Math.max(1, prefs.getInt("intervalMinutes", 15));
            String phrase = prefs.getString("phrase", "اللهم صلّ وسلم وبارك على نبينا محمد ﷺ");
            boolean soundEnabled = prefs.getBoolean("soundEnabled", true);
            boolean vibrateEnabled = prefs.getBoolean("vibrateEnabled", true);
            float soundVolume = prefs.getFloat("soundVolume", 0.9f);
            boolean quietHoursEnabled = prefs.getBoolean("quietHoursEnabled", false);
            int quietStartHour = prefs.getInt("quietStartHour", 23);
            int quietEndHour = prefs.getInt("quietEndHour", 5);

            if (!isWithinQuietHours(quietHoursEnabled, quietStartHour, quietEndHour)) {
                showReminderNotification(context, phrase, vibrateEnabled);
                if (soundEnabled) {
                    Intent svcIntent = new Intent(context, AzkarForegroundService.class);
                    svcIntent.setAction(AzkarForegroundService.ACTION_PLAY_REMINDER);
                    svcIntent.putExtra("volume", soundVolume);
                    svcIntent.putExtra("phrase", phrase);
                    ContextCompat.startForegroundService(context, svcIntent);
                }
            }

            // Schedule next exact alarm so reminders continue reliably across app close, lock screen & reboot
            long nextTriggerAt = System.currentTimeMillis() + (intervalMinutes * 60_000L);
            prefs.edit().putLong("nextTriggerAt", nextTriggerAt).apply();
            scheduleNextAlarm(context, nextTriggerAt);
        } finally {
            if (wakeLock != null && wakeLock.isHeld()) {
                try {
                    wakeLock.release();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private static boolean isWithinQuietHours(boolean enabled, int startHour, int endHour) {
        if (!enabled) return false;
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (startHour <= endHour) {
            return hour >= startHour && hour < endHour;
        }
        return hour >= startHour || hour < endHour;
    }

    public static void ensureNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        // 1. Alert banner channel (silent at OS channel level because AzkarForegroundService plays the full audio
        //    directly on USAGE_NOTIFICATION so Power/Volume keys never interrupt the voice)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            NotificationChannel alertChannel = new NotificationChannel(
                CHANNEL_ID,
                "تنبيهات الأذكار",
                NotificationManager.IMPORTANCE_HIGH
            );
            alertChannel.setDescription("إشعارات التذكير الدورية بالذكر");
            alertChannel.enableVibration(true);
            alertChannel.setVibrationPattern(new long[]{0, 220, 120, 220});
            alertChannel.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);
            alertChannel.setSound(null, null);
            nm.createNotificationChannel(alertChannel);
        }

        // 2. Low-profile foreground keep-alive channel
        if (nm.getNotificationChannel(SERVICE_CHANNEL_ID) == null) {
            NotificationChannel serviceChannel = new NotificationChannel(
                SERVICE_CHANNEL_ID,
                "خدمة التذكير المستمر",
                NotificationManager.IMPORTANCE_LOW
            );
            serviceChannel.setDescription("تُبقي نظام التذكير بالأذكار نشطاً في الخلفية");
            serviceChannel.setSound(null, null);
            serviceChannel.enableVibration(false);
            serviceChannel.setShowBadge(false);
            nm.createNotificationChannel(serviceChannel);
        }
    }

    public static void showReminderNotification(Context context, String phrase, boolean vibrateEnabled) {
        ensureNotificationChannel(context);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        Intent launchIntent = new Intent(context, MainActivity.class);
        launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent contentIntent = PendingIntent.getActivity(context, 0, launchIntent, piFlags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_azkar)
            .setColor(0xFF7C3AED)
            .setContentTitle("✨ {𝐘𝐀𝐇𝐈𝐀} صلّى على الحبيب ♥")
            .setContentText(phrase)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(phrase + "\nسبحان الله والحمد لله والله أكبر"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setSilent(true)
            .setAutoCancel(true)
            .setContentIntent(contentIntent);

        if (vibrateEnabled) {
            builder.setVibrate(new long[]{0, 220, 120, 220});
        }

        nm.notify(NOTIF_ID, builder.build());
    }

    public static void scheduleNextAlarm(Context context, long triggerAtMillis) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent intent = new Intent(context, AzkarAlarmReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, ALARM_REQUEST_CODE, intent, flags);

        am.cancel(pendingIntent);

        Intent showIntent = new Intent(context, MainActivity.class);
        PendingIntent showPendingIntent = PendingIntent.getActivity(context, 7709, showIntent, flags);

        boolean canExact = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            canExact = am.canScheduleExactAlarms();
        }

        if (canExact && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // setAlarmClock bypasses Doze throttling (fires reliably at 1-minute intervals even when locked)
            AlarmManager.AlarmClockInfo info = new AlarmManager.AlarmClockInfo(triggerAtMillis, showPendingIntent);
            am.setAlarmClock(info, pendingIntent);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
        }
    }

    public static void cancelAlarm(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent intent = new Intent(context, AzkarAlarmReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, ALARM_REQUEST_CODE, intent, flags);
        am.cancel(pendingIntent);
    }
}
